---
name: "🔒 Security Vulnerabilities"
about: 'For reporting security-related issues, see: https://github.com/bagito/bagisto#security-vulnerabilities'
---

PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, SEE BELOW.

If you have security vulnerability to address related to Bagisto then please write a mail to us:
**support@bagisto.com**