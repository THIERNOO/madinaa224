<?php

return [
    'hosts' => [
        env('ELASTIC_HOST', 'localhost:9200'),
    ]
];
