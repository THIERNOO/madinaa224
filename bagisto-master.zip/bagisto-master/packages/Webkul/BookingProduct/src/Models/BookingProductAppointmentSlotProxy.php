<?php

namespace Webkul\BookingProduct\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BookingProductAppointmentSlotProxy extends ModelProxy
{

}