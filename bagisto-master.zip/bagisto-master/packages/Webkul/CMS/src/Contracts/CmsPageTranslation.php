<?php

namespace Webkul\CMS\Contracts;

interface CmsPageTranslation
{
}