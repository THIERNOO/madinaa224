<?php

namespace Webkul\CMS\Contracts;

interface CmsPage
{
}